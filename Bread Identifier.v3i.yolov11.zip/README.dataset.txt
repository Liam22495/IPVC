# Bread Identifier > 2025-03-30 6:31pm
https://universe.roboflow.com/bread-identifier/bread-identifier-e0zfy

Provided by a Roboflow user
License: CC BY 4.0

